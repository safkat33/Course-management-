import frames.NSZFrame;

public class NSZGradeExplorer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NSZFrame frame = new NSZFrame();
		frame.showFrame();

	}

}
