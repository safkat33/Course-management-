package frames;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Frame extends javax.swing.JFrame {
	
	public Frame() {
		setSize(646,509);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
